# Exploratory Data Analysis (EDA) and Data Visualization

A beginner-friendly Python project for **Task 2: EDA** and **Task 3: Data Visualization**.

## Features
- Inspects dataset shape, columns, and data types
- Finds missing values and duplicate rows
- Calculates descriptive statistics and potential outliers using the IQR rule
- Generates histograms, a correlation matrix, category counts, missing-value chart, and boxplot when applicable
- Runs a Pearson correlation hypothesis test on the first two numeric columns
- Saves text/JSON reports and PNG charts in `outputs/`

## Setup
Python 3.10+ is recommended.

```bash
python -m pip install -r requirements.txt
python main.py
```

On Windows, if `python` does not work, try:

```bash
py -m pip install -r requirements.txt
py main.py
```

The included `data.csv` is a small example dataset, so you can test the project immediately.

## Use your own CSV
Replace `data.csv` with your own CSV, or specify its path:

```bash
python main.py --data "path/to/your_dataset.csv"
```

## Output files
- `outputs/eda_report.txt`
- `outputs/eda_report.json`
- `outputs/hypothesis_test.json`
- PNG charts created for the columns in your dataset

## Important interpretation note
The default hypothesis test checks the linear correlation between the first two numeric columns. Choose columns and tests according to your research question. Correlation does not prove causation.

## Upload to GitHub
Create a repository named `eda-data-visualization`, then upload `main.py`, `data.csv`, `requirements.txt`, and `README.md`. You can also commit useful generated charts and reports from `outputs/`. Do not upload private or confidential data.
