from pathlib import Path
import argparse
import json
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

warnings.filterwarnings("ignore", category=FutureWarning)
PROJECT_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT_DIR / "outputs"

def detect_outliers_iqr(series):
    values = pd.to_numeric(series, errors="coerce").dropna()
    if values.empty:
        return 0
    q1, q3 = values.quantile([0.25, 0.75])
    iqr = q3 - q1
    if iqr == 0:
        return 0
    return int(((values < q1 - 1.5 * iqr) | (values > q3 + 1.5 * iqr)).sum())

def save_eda_report(df):
    OUTPUT_DIR.mkdir(exist_ok=True)
    numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
    categorical_cols = df.select_dtypes(include=["object", "category", "bool"]).columns.tolist()
    report = {
        "dataset_shape": {"rows": int(df.shape[0]), "columns": int(df.shape[1])},
        "column_names": df.columns.tolist(),
        "data_types": {c: str(t) for c, t in df.dtypes.items()},
        "missing_values": {c: int(n) for c, n in df.isna().sum().items()},
        "duplicate_rows": int(df.duplicated().sum()),
        "numeric_summary": df[numeric_cols].describe().round(3).to_dict() if numeric_cols else {},
        "outlier_counts_iqr": {c: detect_outliers_iqr(df[c]) for c in numeric_cols},
        "categorical_unique_counts": {c: int(df[c].nunique(dropna=True)) for c in categorical_cols}
    }
    (OUTPUT_DIR / "eda_report.json").write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    with (OUTPUT_DIR / "eda_report.txt").open("w", encoding="utf-8") as f:
        f.write("EXPLORATORY DATA ANALYSIS REPORT\n" + "=" * 34 + "\n\n")
        f.write(f"Rows: {df.shape[0]}\nColumns: {df.shape[1]}\nDuplicate rows: {df.duplicated().sum()}\n\n")
        f.write("DATA TYPES\n" + df.dtypes.to_string() + "\n\n")
        f.write("MISSING VALUES\n" + df.isna().sum().to_string() + "\n\n")
        if numeric_cols:
            f.write("NUMERICAL SUMMARY\n" + df[numeric_cols].describe().round(3).to_string() + "\n\n")
            f.write("OUTLIER COUNTS (IQR RULE)\n" + str(report["outlier_counts_iqr"]) + "\n")
        if categorical_cols:
            f.write("\nCATEGORICAL UNIQUE COUNTS\n" + str(report["categorical_unique_counts"]) + "\n")
    return numeric_cols, categorical_cols

def create_visualizations(df, numeric_cols, categorical_cols):
    OUTPUT_DIR.mkdir(exist_ok=True)
    saved = []
    for col in numeric_cols[:6]:
        values = pd.to_numeric(df[col], errors="coerce").dropna()
        if values.empty:
            continue
        plt.figure(figsize=(8, 5))
        plt.hist(values, bins="auto", edgecolor="black")
        plt.title(f"Distribution of {col}")
        plt.xlabel(col); plt.ylabel("Frequency"); plt.tight_layout()
        path = OUTPUT_DIR / f"histogram_{col}.png"
        plt.savefig(path, dpi=150); plt.close(); saved.append(path.name)
    if len(numeric_cols) >= 2:
        corr = df[numeric_cols].corr(numeric_only=True)
        fig, ax = plt.subplots(figsize=(max(7, len(corr.columns)), max(5, len(corr.columns) * 0.7)))
        im = ax.imshow(corr, cmap="coolwarm", vmin=-1, vmax=1, aspect="auto")
        ax.set_xticks(range(len(corr.columns))); ax.set_xticklabels(corr.columns, rotation=45, ha="right")
        ax.set_yticks(range(len(corr.index))); ax.set_yticklabels(corr.index)
        ax.set_title("Correlation Matrix"); fig.colorbar(im, ax=ax, label="Correlation")
        fig.tight_layout()
        path = OUTPUT_DIR / "correlation_matrix.png"
        fig.savefig(path, dpi=150); plt.close(fig); saved.append(path.name)
    missing = df.isna().sum()
    missing = missing[missing > 0].sort_values(ascending=False)
    if not missing.empty:
        plt.figure(figsize=(9, 5)); missing.plot(kind="bar", edgecolor="black")
        plt.title("Missing Values by Column"); plt.xlabel("Column"); plt.ylabel("Missing count")
        plt.xticks(rotation=45, ha="right"); plt.tight_layout()
        path = OUTPUT_DIR / "missing_values.png"
        plt.savefig(path, dpi=150); plt.close(); saved.append(path.name)
    if categorical_cols:
        col = categorical_cols[0]
        counts = df[col].astype("string").fillna("Missing").value_counts().head(10)
        plt.figure(figsize=(9, 5)); counts.plot(kind="bar", edgecolor="black")
        plt.title(f"Top Categories in {col}"); plt.xlabel(col); plt.ylabel("Count")
        plt.xticks(rotation=35, ha="right"); plt.tight_layout()
        path = OUTPUT_DIR / f"categories_{col}.png"
        plt.savefig(path, dpi=150); plt.close(); saved.append(path.name)
    if numeric_cols and categorical_cols:
        num_col, cat_col = numeric_cols[0], categorical_cols[0]
        temp = df[[num_col, cat_col]].dropna()
        top_groups = temp[cat_col].value_counts().head(8).index
        temp = temp[temp[cat_col].isin(top_groups)]
        pairs = [(str(g), temp.loc[temp[cat_col] == g, num_col].dropna().values) for g in top_groups]
        pairs = [(g, v) for g, v in pairs if len(v)]
        if len(pairs) >= 2:
            plt.figure(figsize=(9, 5))
            plt.boxplot([v for _, v in pairs], labels=[g for g, _ in pairs])
            plt.title(f"{num_col} by {cat_col}"); plt.xlabel(cat_col); plt.ylabel(num_col)
            plt.xticks(rotation=35, ha="right"); plt.tight_layout()
            path = OUTPUT_DIR / "group_boxplot.png"
            plt.savefig(path, dpi=150); plt.close(); saved.append(path.name)
    return saved

def run_hypothesis_test(df, numeric_cols):
    result = {
        "test": "Pearson correlation test on the first two numeric columns",
        "null_hypothesis": "The population linear correlation is zero.",
        "alternative_hypothesis": "The population linear correlation is not zero."
    }
    if len(numeric_cols) < 2:
        result["result"] = "Skipped: at least two numeric columns are needed."
        return result
    pair = df[numeric_cols[:2]].apply(pd.to_numeric, errors="coerce").dropna()
    if len(pair) < 3 or pair.iloc[:, 0].nunique() < 2 or pair.iloc[:, 1].nunique() < 2:
        result["result"] = "Skipped: need at least 3 complete rows and variation in both columns."
        return result
    r, p = stats.pearsonr(pair.iloc[:, 0], pair.iloc[:, 1])
    result.update({
        "columns": pair.columns.tolist(), "complete_rows": int(len(pair)),
        "pearson_r": round(float(r), 4), "p_value": round(float(p), 6),
        "significance_level": 0.05,
        "interpretation": "Statistically significant linear association (p < 0.05)." if p < 0.05 else
                          "No statistically significant linear association detected at the 0.05 level.",
        "caution": "Correlation does not prove causation; check assumptions and context."
    })
    return result

def main():
    parser = argparse.ArgumentParser(description="EDA and data visualization")
    parser.add_argument("--data", default=str(PROJECT_DIR / "data.csv"), help="Path to input CSV")
    args = parser.parse_args()
    data_path = Path(args.data)
    if not data_path.exists():
        raise FileNotFoundError(f"Dataset not found: {data_path}. Add data.csv or use --data path/to/file.csv")
    df = pd.read_csv(data_path)
    if df.empty:
        raise ValueError("The dataset has no rows.")
    print("\\n=== DATASET OVERVIEW ===")
    print(f"Shape: {df.shape[0]} rows × {df.shape[1]} columns")
    print("\\nFirst five rows:\\n", df.head().to_string(index=False))
    print("\\nData types:\\n", df.dtypes.to_string())
    print("\\nMissing values:\\n", df.isna().sum().to_string())
    print(f"\\nDuplicate rows: {df.duplicated().sum()}")
    numeric_cols, categorical_cols = save_eda_report(df)
    charts = create_visualizations(df, numeric_cols, categorical_cols)
    hypothesis = run_hypothesis_test(df, numeric_cols)
    (OUTPUT_DIR / "hypothesis_test.json").write_text(json.dumps(hypothesis, indent=2), encoding="utf-8")
    print("\\n=== HYPOTHESIS TEST ===\\n", json.dumps(hypothesis, indent=2))
    print("\\nReports saved in outputs/eda_report.txt and outputs/eda_report.json")
    print("Hypothesis test saved in outputs/hypothesis_test.json")
    for chart in charts:
        print("Chart saved: outputs/" + chart)
    print("\\nAnalysis complete.")

if __name__ == "__main__":
    main()
